import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ShoppingCart, Gamepad2, Ticket, Gift, Zap, ShieldCheck,
  LayoutDashboard, Search, Menu, X, Plus, Minus, Trash2,
  ArrowLeft, CheckCircle2, Sparkles
} from "lucide-react";
import "./index.css";

const categories = [
  { id: "games", title: "بطاقات الألعاب", icon: Gamepad2, emoji: "🎮" },
  { id: "subs", title: "الاشتراكات", icon: Ticket, emoji: "🎫" },
  { id: "gifts", title: "بطاقات الهدايا", icon: Gift, emoji: "🎁" },
  { id: "digital", title: "الخدمات الرقمية", icon: Zap, emoji: "⚡" }
];

const products = [
  { id: 1, name: "PUBG Mobile 660 UC", price: 12500, category: "games", badge: "الأكثر مبيعاً", image: "https://placehold.co/700x520/111111/FF4B2B?text=PUBG+660+UC" },
  { id: 2, name: "Netflix Premium — شهر", price: 15000, category: "subs", badge: "عرض", image: "https://placehold.co/700x520/111111/FF416C?text=NETFLIX+PREMIUM" },
  { id: 3, name: "iTunes Gift Card — $10", price: 14750, category: "gifts", badge: "جديد", image: "https://placehold.co/700x520/111111/F5F5F5?text=ITUNES+%2410" },
  { id: 4, name: "PlayStation Store — $10", price: 15500, category: "gifts", image: "https://placehold.co/700x520/111111/FF4B2B?text=PSN+%2410" },
  { id: 5, name: "Xbox Gift Card — $10", price: 15000, category: "gifts", image: "https://placehold.co/700x520/111111/FF416C?text=XBOX+%2410" },
  { id: 6, name: "Game Pass Ultimate — شهر", price: 18000, category: "subs", badge: "مميز", image: "https://placehold.co/700x520/111111/F5F5F5?text=GAME+PASS" }
];

const money = n => new Intl.NumberFormat("ar-IQ").format(n) + " د.ع";

function App() {
  const [cart, setCart] = useState([]);
  const [activeCategory, setActiveCategory] = useState("all");
  const [search, setSearch] = useState("");
  const [mobileMenu, setMobileMenu] = useState(false);
  const [checkout, setCheckout] = useState(false);
  const [notice, setNotice] = useState("");

  const filtered = useMemo(() => products.filter(p => {
    const categoryOk = activeCategory === "all" || p.category === activeCategory;
    return categoryOk && p.name.toLowerCase().includes(search.toLowerCase());
  }), [activeCategory, search]);

  const cartCount = cart.reduce((s, x) => s + x.qty, 0);
  const total = cart.reduce((s, x) => s + x.price * x.qty, 0);

  function addToCart(product) {
    setCart(old => {
      const found = old.find(x => x.id === product.id);
      return found ? old.map(x => x.id === product.id ? {...x, qty: x.qty + 1} : x)
                   : [...old, {...product, qty: 1}];
    });
    setNotice("تمت إضافة المنتج إلى السلة");
    setTimeout(() => setNotice(""), 1800);
  }

  function changeQty(id, delta) {
    setCart(old => old.map(x => x.id === id ? {...x, qty: Math.max(1, x.qty + delta)} : x));
  }

  function remove(id) { setCart(old => old.filter(x => x.id !== id)); }

  return (
    <div className="min-h-screen bg-darkBg text-premiumWhite font-cairo" dir="rtl">
      <header className="fixed top-0 inset-x-0 z-50 border-b border-white/5 bg-[#050505]/80 backdrop-blur-xl">
        <nav className="max-w-7xl mx-auto px-5 md:px-8 h-20 flex items-center justify-between">
          <a href="#home" className="text-3xl font-black tracking-tight bg-gradient-to-l from-elytexOrange to-elytexRed bg-clip-text text-transparent">
            ELYTEX
          </a>
          <div className="hidden md:flex items-center gap-7 text-sm text-gray-300">
            {[
              ["#home","الرئيسية"],["#store","المتجر"],["#offers","العروض"],
              ["#faq","الأسئلة الشائعة"],["#contact","تواصل معنا"]
            ].map(([href,label]) => <a key={href} href={href} className="hover:text-white hover:-translate-y-0.5 transition">{label}</a>)}
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setCheckout(true)} className="relative p-3 rounded-xl bg-white/5 hover:bg-white/10 transition" aria-label="السلة">
              <ShoppingCart size={20}/>
              {cartCount > 0 && <span className="absolute -top-1 -left-1 min-w-5 h-5 px-1 rounded-full bg-elytexOrange text-white text-[10px] font-black flex items-center justify-center">{cartCount}</span>}
            </button>
            <button className="hidden sm:flex items-center gap-2 bg-white text-black px-5 py-2.5 rounded-xl font-bold hover:bg-elytexOrange hover:text-white transition">
              <LayoutDashboard size={17}/> حسابي
            </button>
            <button onClick={() => setMobileMenu(!mobileMenu)} className="md:hidden p-3 rounded-xl bg-white/5">
              {mobileMenu ? <X/> : <Menu/>}
            </button>
          </div>
        </nav>
        {mobileMenu && <div className="md:hidden px-5 pb-5 border-t border-white/5 bg-[#080808]">
          {["#home","#store","#offers","#faq","#contact"].map((href,i) => <a key={href} onClick={() => setMobileMenu(false)} href={href} className="block py-3 text-gray-300">{["الرئيسية","المتجر","العروض","الأسئلة الشائعة","تواصل معنا"][i]}</a>)}
        </div>}
      </header>

      <main id="home" className="pt-20">
        <section className="relative overflow-hidden grid-bg">
          <div className="absolute -top-40 -right-40 w-[500px] h-[500px] rounded-full bg-elytexOrange/10 blur-[120px]"/>
          <div className="absolute top-40 -left-40 w-[450px] h-[450px] rounded-full bg-elytexRed/10 blur-[120px]"/>
          <div className="max-w-7xl mx-auto px-5 md:px-8 py-20 md:py-28 grid md:grid-cols-2 gap-14 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 text-sm text-gray-300 mb-6">
                <Sparkles size={15} className="text-elytexOrange"/> متجر رقمي من ELYTEX
              </div>
              <h1 className="text-5xl md:text-7xl font-black leading-[1.08]">
                ELYTEX <span className="text-elytexOrange">STORE</span>
              </h1>
              <p className="text-lg md:text-xl text-gray-400 mt-6 max-w-xl leading-9">
                متجرك الرقمي... أسرع، أسهل، وأكثر أماناً.
                بطاقات ألعاب، اشتراكات، بطاقات هدايا وخدمات رقمية بتجربة شراء بسيطة.
              </p>
              <div className="flex flex-wrap gap-3 mt-8">
                <a href="#store" className="bg-gradient-to-l from-elytexOrange to-elytexRed px-8 py-4 rounded-2xl font-black hover:scale-[1.03] transition shadow-xl shadow-elytexOrange/10">ابدأ التسوق الآن</a>
                <a href="#offers" className="px-8 py-4 rounded-2xl font-bold border border-white/10 bg-white/5 hover:bg-white/10 transition">شاهد العروض</a>
              </div>
              <div className="flex gap-6 mt-9 text-sm text-gray-400">
                <span className="flex items-center gap-2"><ShieldCheck size={17} className="text-elytexOrange"/> دفع آمن</span>
                <span className="flex items-center gap-2"><Zap size={17} className="text-elytexOrange"/> تسليم سريع</span>
              </div>
            </div>
            <div className="relative flex justify-center">
              <div className="absolute w-72 h-72 bg-elytexOrange/20 blur-[90px] rounded-full"/>
              <div className="relative w-full max-w-md aspect-[4/5] rounded-[42px] border border-white/10 bg-gradient-to-br from-white/[.08] to-white/[.015] p-7 overflow-hidden glow">
                <div className="absolute inset-0 bg-gradient-to-br from-elytexOrange/15 via-transparent to-elytexRed/10"/>
                <div className="relative h-full flex flex-col justify-between">
                  <div className="flex justify-between items-start">
                    <span className="text-2xl font-black italic">ELYTEX</span>
                    <span className="text-xs px-3 py-1.5 rounded-full bg-white/10">PREMIUM</span>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500 mb-3">DIGITAL STORE</div>
                    <div className="h-2 w-4/5 bg-white/10 rounded-full mb-3"/>
                    <div className="h-2 w-1/2 bg-white/10 rounded-full"/>
                  </div>
                  <div className="flex justify-between items-end">
                    <div className="text-elytexOrange font-black tracking-[.2em]">E-X STORE</div>
                    <Gamepad2 size={42} className="text-white/20"/>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="store" className="py-20 px-5 md:px-8 bg-black/30">
          <div className="max-w-7xl mx-auto">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-5 mb-10">
              <div><p className="text-elytexOrange font-bold mb-2">STORE</p><h2 className="text-4xl font-black">تسوق حسب القسم</h2></div>
              <div className="relative w-full md:w-80">
                <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500" size={19}/>
                <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="ابحث عن منتج..." className="w-full bg-cardBg border border-white/10 rounded-2xl py-3 pr-11 pl-4 outline-none focus:border-elytexOrange/60"/>
              </div>
            </div>

            <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2 mb-10">
              <button onClick={()=>setActiveCategory("all")} className={`min-w-max px-6 py-4 rounded-2xl border font-bold transition ${activeCategory==="all"?"bg-white text-black border-white":"bg-cardBg border-white/5 text-gray-300"}`}>كل المنتجات</button>
              {categories.map(c => <button key={c.id} onClick={()=>setActiveCategory(c.id)} className={`min-w-max px-6 py-4 rounded-2xl border font-bold transition ${activeCategory===c.id?"bg-gradient-to-l from-elytexOrange to-elytexRed border-transparent":"bg-cardBg border-white/5 text-gray-300 hover:border-white/15"}`}>{c.emoji} {c.title}</button>)}
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-5 mb-16">
              {categories.map(c => {
                const Icon=c.icon;
                return <button key={c.id} onClick={()=>setActiveCategory(c.id)} className="text-right bg-cardBg p-6 rounded-3xl border border-white/5 hover:border-elytexOrange/40 hover:-translate-y-1 transition-all group">
                  <div className="w-12 h-12 rounded-2xl bg-elytexOrange/10 text-elytexOrange flex items-center justify-center mb-5 group-hover:scale-110 transition"><Icon/></div>
                  <div className="font-bold">{c.title}</div><div className="text-xs text-gray-500 mt-1">تصفح المنتجات {c.emoji}</div>
                </button>
              })}
            </div>

            <div className="flex items-center justify-between mb-6"><h3 className="text-2xl font-black">منتجات مختارة</h3><span className="text-sm text-gray-500">{filtered.length} منتجات</span></div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-7">
              {filtered.map(p => <ProductCard key={p.id} product={p} onAdd={addToCart}/>)}
            </div>
            {filtered.length===0 && <div className="py-20 text-center text-gray-500">ما لقينا منتجات مطابقة للبحث.</div>}
          </div>
        </section>

        <section id="offers" className="py-20 px-5 md:px-8">
          <div className="max-w-7xl mx-auto rounded-[36px] border border-white/10 bg-gradient-to-l from-elytexOrange/15 via-white/[.03] to-elytexRed/10 p-8 md:p-14 overflow-hidden relative">
            <div className="absolute -left-20 -top-20 w-60 h-60 rounded-full bg-elytexRed/10 blur-3xl"/>
            <div className="relative grid md:grid-cols-2 gap-8 items-center">
              <div><p className="text-elytexOrange font-bold mb-2">LIMITED OFFERS</p><h2 className="text-4xl md:text-5xl font-black">عروض قوية،<br/><span className="text-elytexOrange">لفترة محدودة.</span></h2><p className="text-gray-400 mt-5">تابع العروض داخل المتجر واحصل على أفضل الأسعار للمنتجات الرقمية.</p></div>
              <div className="flex md:justify-end"><a href="#store" className="inline-flex items-center gap-2 bg-white text-black px-7 py-4 rounded-2xl font-black hover:bg-elytexOrange hover:text-white transition">استكشف المتجر <ArrowLeft size={18}/></a></div>
            </div>
          </div>
        </section>

        <section id="faq" className="py-20 px-5 md:px-8 bg-black/30">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-black mb-10">الأسئلة الشائعة</h2>
            {[
              ["شلون أشتري؟","اختار المنتج، أضفه للسلة، وبعدها أكمل بيانات الطلب."],
              ["متى يوصل الطلب؟","المنتجات الرقمية تكون مهيأة للتسليم بعد تأكيد الطلب، حسب نوع الخدمة وطريقة الدفع."],
              ["هل أگدر أتواصل وياكم؟","إي، استخدم قسم التواصل بالأسفل حتى تضيف قناة الدعم الخاصة بالمتجر."]
            ].map(([q,a])=><details key={q} className="group border-b border-white/10 py-5"><summary className="cursor-pointer font-bold list-none flex justify-between">{q}<Plus className="group-open:rotate-45 transition"/></summary><p className="text-gray-400 mt-4 leading-8">{a}</p></details>)}
          </div>
        </section>
      </main>

      <footer id="contact" className="border-t border-white/5 py-12 px-5 md:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between gap-8">
          <div><div className="text-3xl font-black text-elytexOrange">ELYTEX</div><p className="text-gray-500 mt-2">Digital Store • Gaming • Services</p></div>
          <div className="text-sm text-gray-500 leading-8"><div className="text-white font-bold">تواصل معنا</div><div>أضف هنا رابط الديسكورد / واتساب / تيليغرام</div></div>
          <div className="text-sm text-gray-600">© 2026 ELYTEX STORE. All rights reserved.</div>
        </div>
      </footer>

      {notice && <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[80] bg-white text-black px-6 py-3 rounded-2xl font-bold shadow-2xl flex items-center gap-2"><CheckCircle2 size={18} className="text-elytexOrange"/>{notice}</div>}

      {checkout && <CartDrawer cart={cart} total={total} onClose={()=>setCheckout(false)} onChange={changeQty} onRemove={remove} onCheckout={()=>alert("واجهة الدفع جاهزة للربط ببوابة الدفع الخاصة بك.")}/>}
    </div>
  );
}

function ProductCard({product,onAdd}) {
  return <article className="bg-cardBg rounded-[30px] p-4 border border-white/5 hover:border-elytexOrange/30 hover:-translate-y-1 transition-all group">
    <div className="relative overflow-hidden rounded-[22px] mb-5">
      <img src={product.image} alt={product.name} className="w-full aspect-[4/3] object-cover group-hover:scale-105 transition duration-500"/>
      {product.badge && <span className="absolute top-3 right-3 bg-black/75 backdrop-blur px-3 py-1.5 rounded-full text-xs font-bold text-elytexOrange border border-white/10">{product.badge}</span>}
    </div>
    <h3 className="font-bold text-lg min-h-14">{product.name}</h3>
    <div className="flex items-end justify-between gap-3 mt-5">
      <div><div className="text-2xl font-black">{money(product.price)}</div><div className="text-xs text-gray-500">السعر النهائي</div></div>
      <button onClick={()=>onAdd(product)} className="bg-white text-black px-4 py-3 rounded-xl font-black hover:bg-elytexOrange hover:text-white transition flex items-center gap-2"><ShoppingCart size={17}/> شراء</button>
    </div>
  </article>
}

function CartDrawer({cart,total,onClose,onChange,onRemove,onCheckout}) {
  return <div className="fixed inset-0 z-[70] bg-black/70 backdrop-blur-sm" onClick={onClose}>
    <aside onClick={e=>e.stopPropagation()} className="absolute top-0 left-0 h-full w-full max-w-md bg-[#0a0a0a] border-r border-white/10 p-6 overflow-y-auto">
      <div className="flex items-center justify-between mb-8"><h2 className="text-2xl font-black">سلة المشتريات</h2><button onClick={onClose} className="p-2 rounded-xl bg-white/5"><X/></button></div>
      {cart.length===0 ? <div className="h-[70vh] flex flex-col items-center justify-center text-center text-gray-500"><ShoppingCart size={50} className="mb-4 opacity-30"/><p>السلة فارغة حالياً.</p><a href="#store" onClick={onClose} className="text-elytexOrange mt-3">اذهب للمتجر</a></div> :
      <>
        <div className="space-y-4">{cart.map(x=><div key={x.id} className="p-4 rounded-2xl bg-white/[.03] border border-white/5">
          <div className="flex gap-3"><img src={x.image} className="w-20 h-16 object-cover rounded-xl"/><div className="flex-1"><div className="font-bold text-sm">{x.name}</div><div className="text-elytexOrange font-black mt-1">{money(x.price)}</div></div><button onClick={()=>onRemove(x.id)} className="text-gray-500 hover:text-red-400"><Trash2 size={17}/></button></div>
          <div className="flex items-center justify-between mt-3"><span className="text-xs text-gray-500">الكمية</span><div className="flex items-center gap-3"><button onClick={()=>onChange(x.id,-1)} className="p-1.5 bg-white/5 rounded-lg"><Minus size={14}/></button><b>{x.qty}</b><button onClick={()=>onChange(x.id,1)} className="p-1.5 bg-white/5 rounded-lg"><Plus size={14}/></button></div></div>
        </div>)}</div>
        <div className="border-t border-white/10 mt-7 pt-6"><div className="flex justify-between text-lg font-black mb-5"><span>الإجمالي</span><span className="text-elytexOrange">{money(total)}</span></div><button onClick={onCheckout} className="w-full bg-gradient-to-l from-elytexOrange to-elytexRed py-4 rounded-2xl font-black">متابعة إلى الدفع</button></div>
      </>}
    </aside>
  </div>
}

createRoot(document.getElementById("root")).render(<App />);
